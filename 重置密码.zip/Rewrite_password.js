window.onload = function () {
    const password = document.getElementsByClassName('password')
    const btn = document.getElementsByClassName('submit')[0]
    const span = document.getElementsByTagName('span')
    //密码验证规则
    const reg = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*,\.])[0-9a-zA-Z!@#$%^&*,\\.]{4,}$/
    password[0].onblur = function () {
        span[0].innerHTML = ''
    }
    //对密码进行校验
    password[0].oninput = function () {
        if (reg.test(password[0].value)) {
            //验证成功
            span[0].className = 'right'
            span[0].innerHTML = '&nbsp;&nbsp;密码形式正确'
        } else {
            //验证失败
            span[0].className = 'error'
            span[0].innerHTML = '&nbsp;&nbsp;请输入包含大小写字母、符号、数字的密码'
        }
    }
    //对密码进行确认
    password[1].oninput = function () {
        if (password[0].value == password[1].value) {
            //密码一致
            span[1].className = 'right'
            span[1].innerHTML = '&nbsp;&nbsp;两次密码输入一致'
        } else {
            //密码不同
            span[1].className = 'error'
            span[1].innerHTML = '&nbsp;&nbsp;两次密码输入不相同'
        }
    }
    password[1].onblur = function () {
        span[1].innerHTML = ''
        //提交
        btn.onclick = function () {
        if (password[0].value != '' && password[1].value != '') {
                //响应成功
                jsonp({
                    url:'https://oj.gocybee.team/api/user/password/confirm',
                    data:{
                        code:'lZoSJXuL7uN5TOaSl5cEBIXauRgiQpSawSjvU29uo9FLau4xtmw',
                        password:'aA1!23'
                    },
                    success:function(data){
                        console.log(data)
                    }
                })
             }
            }
    }

}
