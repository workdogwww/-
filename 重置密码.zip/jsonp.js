function jsonp(options) {
    //动态创建script标签添加到页面
    let script = document.createElement('script')
    //添加请求参数
    let params = ''
    for (let attr in options.data) {
        params += '&' + attr + '=' + options.data[attr]
    }
    //随机生成一个函数名
    const fnName = 'myJsonp' + Math.random().toString().replace('.', "")
    //将传入函数设置为全局函数
    window[fnName] = options.success
    script.src = options.url + '?callback=' + fnName + params
    document.body.appendChild(script)
    //当script加载完
    script.onload = function () {
        document.body.removeChild(script)
    }
}